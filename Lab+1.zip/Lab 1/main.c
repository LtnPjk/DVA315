#include "wrapper.h"

int main(int ac, char * argv)
{
	pthread_t * hej;
	printf("Hello world!");
}
