#include "wrapper.h"

int main()
{
	//Implement you inter process communication here, happy coding
}
